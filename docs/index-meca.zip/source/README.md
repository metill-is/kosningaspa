# A Dynamic Generalized Linear Model for Predicting the Icelandic Parliamentary Elections

This repository contains the code and data for a dynamic generalized linear model for predicting the outcome of the Icelandic Parliamentary Elections.
